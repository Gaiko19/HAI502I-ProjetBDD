CREATE TABLE "RESERVES" (
  "idreserves" VARCHAR(42),
  "typereserve" VARCHAR(42),
  "quantite" VARCHAR(42),
  "quantitemax" VARCHAR(42),
  "idvillage" VARCHAR(42),
  PRIMARY KEY ("idreserves")
);

CREATE TABLE "CLAN" (
  "idclan" VARCHAR(42),
  "nomclan" VARCHAR(42),
  "regionclan" VARCHAR(42),
  "niveauclan" VARCHAR(42),
  "idvillage" VARCHAR(42),
  PRIMARY KEY ("idclan")
);

CREATE TABLE "HEROS" (
  "idheros" VARCHAR(42),
  "typeheros" VARCHAR(42),
  "niveauheros" VARCHAR(42),
  "vieheros" VARCHAR(42),
  "idvillage" VARCHAR(42),
  PRIMARY KEY ("idheros")
);

CREATE TABLE "VILLAGE" (
  "idvillage" VARCHAR(42),
  "nomjoueur" VARCHAR(42),
  "niveaujoueur" VARCHAR(42),
  "capacitecampmax" VARCHAR(42),
  "trophees" VARCHAR(42),
  "idclan" VARCHAR(42),
  PRIMARY KEY ("idvillage")
);

CREATE TABLE "GUERREDECLAN" (
  "idguerre" VARCHAR(42),
  "idclan1" VARCHAR(42),
  "idclan2" VARCHAR(42),
  "datedebut" VARCHAR(42),
  "etoilesclan1" VARCHAR(42),
  "etoilesclan2" VARCHAR(42),
  "idclan" VARCHAR(42),
  PRIMARY KEY ("idguerre")
);

CREATE TABLE "TROUPE" (
  "idtroupe" VARCHAR(42),
  "nomtroupe" VARCHAR(42),
  "pointsvie" VARCHAR(42),
  "degats" VARCHAR(42),
  "placeoccupee" VARCHAR(42),
  "prixelixir" VARCHAR(42),
  "prixelixirnoir" VARCHAR(42),
  "idvillage" VARCHAR(42),
  "capacitemax" VARCHAR(42),
  PRIMARY KEY ("idtroupe")
);

CREATE TABLE "ATTAQUE" (
  "idattaque" VARCHAR(42),
  "idattaquant" VARCHAR(42),
  "iddefenseur" VARCHAR(42),
  "nombreetoiles" VARCHAR(42),
  "pourcentage" VARCHAR(42),
  "elixirrecolte" VARCHAR(42),
  "orrecolte" VARCHAR(42),
  "elixirnoirrecolte" VARCHAR(42),
  "idguerre" VARCHAR(42),
  "idvillage" VARCHAR(42),
  PRIMARY KEY ("idattaque")
);

ALTER TABLE "RESERVES" ADD FOREIGN KEY ("idvillage") REFERENCES "VILLAGE" ("idvillage");
ALTER TABLE "CLAN" ADD FOREIGN KEY ("idvillage") REFERENCES "VILLAGE" ("idvillage");
ALTER TABLE "HEROS" ADD FOREIGN KEY ("idvillage") REFERENCES "VILLAGE" ("idvillage");
ALTER TABLE "VILLAGE" ADD FOREIGN KEY ("idclan") REFERENCES "CLAN" ("idclan");
ALTER TABLE "GUERREDECLAN" ADD FOREIGN KEY ("idclan") REFERENCES "CLAN" ("idclan");
ALTER TABLE "TROUPE" ADD FOREIGN KEY ("idvillage") REFERENCES "VILLAGE" ("idvillage");
ALTER TABLE "ATTAQUE" ADD FOREIGN KEY ("idvillage") REFERENCES "VILLAGE" ("idvillage");
ALTER TABLE "ATTAQUE" ADD FOREIGN KEY ("idguerre") REFERENCES "GUERREDECLAN" ("idguerre");